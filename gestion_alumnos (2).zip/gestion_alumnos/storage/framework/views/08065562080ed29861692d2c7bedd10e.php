<?php $__env->startSection('contenido_main'); ?>
    <div>
      
        <h1>Estoy en la parte principal con número <?php echo e($numero); ?></h1>
        <h2>Estoy en la parte principal con nombre <?php echo e($nombre); ?></h2>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\laravel\gestion_alumnos\resources\views/main.blade.php ENDPATH**/ ?>