<?php $__env->startSection("contenido_main"); ?>

    <table>
        <tr>
            <td>Nombre</td>
            <td>Apellido</td>
            <td>Direccion</td>
            <td>Dni</td>
            <td>Email</td>
        </tr>

        <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                <td><?php echo e($alumno->nombre); ?></td>
                <td><?php echo e($alumno->apellido); ?></td>
                <td> <?php echo e($alumno->direccion); ?></td>
                <td> <?php echo e($alumno->dni); ?></td>
                <td> <?php echo e($alumno->email); ?></td>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
    <?php echo e($alumnos ->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\laravel\gestion_alumnos\resources\views/alumnos.blade.php ENDPATH**/ ?>