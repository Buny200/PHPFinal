<?php $__env->startSection("contenido_main"); ?>


    <tabla campos_serializados='<?php echo json_encode($campos, 15, 512) ?>'  filas_serializadas='<?php echo json_encode($filas, 15, 512) ?>' titulo='<?php echo e($titulo); ?>'>

        <caption>
             Alumno
        </caption>

    </tabla>
































<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\laravel\gestion_alumnos\resources\views/alumnos/listado.blade.php ENDPATH**/ ?>