<?php $__env->startSection("contenido main"); ?>
    <h1>estoy en la parte about </h1>
    <h2>estoy en la parte about 2</h2>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Alumno\laravel\gestion_alumnos\resources\views/about.blade.php ENDPATH**/ ?>