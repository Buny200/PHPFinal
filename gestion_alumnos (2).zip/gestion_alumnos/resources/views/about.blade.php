@extends("layout")
@section("contenido main")
    <h1>estoy en la parte about </h1>
    <h2>estoy en la parte about 2</h2>
@endsection
